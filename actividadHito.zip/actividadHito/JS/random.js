//Mostrar lista de miembros y resultado con getElementbyId
var arriba = document.getElementById('miembros');
        var abajo = document.getElementById('resultado');
        //Array con miembros 
        var array = ["Carlos", "Javier", "Maria", "Roberto"];

        //Reemplazar el <p> por el contenido del array
        arriba.innerHTML =  array;
        
        //Función para mostrar miembros
        function mostrar() {
            abajo.innerHTML = array[Math.floor(Math.random() * array.length)];
        }